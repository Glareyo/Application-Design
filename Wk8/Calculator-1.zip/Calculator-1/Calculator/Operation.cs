﻿namespace CalculatorNS
{
    public enum Operation
    {
        Add,
        Subtract,
        Multiply,
        Divide
    }
}
